# Finoptima Illustration Storyboard

> Phase 1 analysis document. Do not build until approved.
> Generated from audit of 41 SVGs, 9 components, and 4 reference PDFs.

---

## 1. Illustration Audit

### Style Families Present

Two distinct illustration styles exist in the library:

| Style | Files | Primary Color | Detail Level | Consistency |
|-------|-------|--------------|--------------|-------------|
| **unDraw** | 34 files | #6c63ff (purple) | Flat, minimal | All match |
| **Storyset** | 7 files | Varies by sub-style | Rich, detailed | 4 sub-styles clash |

Storyset sub-styles present:
- **bro** (Finance, Business competition, Payment Information) — #263238 dark + #92E3A9 green
- **rafiki** (Credit card) — #407BFF blue
- **amico** (Credit card, Tax) — #BA68C8 purple
- **cuate** (Revenue) — #263238 dark + #FFC727 gold

**Decision: Use unDraw only.**
Mixing styles signals amateur design. unDraw's consistent flat style
recolors cleanly to our brand palette and won't compete with survey UI.
Storyset files are visually heavier (66K+ tokens in SVG) and fight for
attention on pages that need the user focused on tasks.

---

### Full Audit Table

| # | Filename | Depicts | ViewBox | Accent Color | Suitability |
|---|----------|---------|---------|-------------|-------------|
| 1 | undraw_choose-card_es1o.svg | Person choosing between 5 credit cards, one highlighted | 825x529 | #6c63ff | **HERO** |
| 2 | undraw_credit-card-payments_y0vn.svg | Hand holding card with payment confirmation dialog | 800x740 | #6c63ff | **Section** |
| 3 | undraw_make-it-rain_vyg9.svg | Two people celebrating with money raining | 731x550 | #6c63ff | **Section** |
| 4 | undraw_business-analytics_y8m6.svg | Person analyzing charts and data dashboards | 960x600 | #6c63ff | **Section** |
| 5 | undraw_personal-information_h7kf.svg | Person standing next to profile/identity form | 800x533 | #6c63ff | **Section** |
| 6 | undraw_questions_52ic.svg | Person thinking with question mark bubbles | 960x677 | #6c63ff | **Card** |
| 7 | undraw_server-error_syuz.svg | Server rack with error state | 697x410 | #6c63ff | **Error state** |
| 8 | undraw_page-not-found_6wni.svg | Person looking at 404 screen | 731x800 | #6c63ff | **Error state** |
| 9 | undraw_mobile-payments_uate.svg | Phone with payment interface | 720x718 | #6c63ff | Reserve |
| 10 | undraw_credit-card-payment_3zqz.svg | Person tapping card on terminal | 816x549 | #6c63ff | Reserve |
| 11 | undraw_pay-online_806n.svg | Woman at computer making payment | 619x562 | #6c63ff | Skip — weaker than #1 |
| 12 | undraw_payments_nbqu.svg | Person with mobile + card integration | 773x419 | #6c63ff | Skip — too generic |
| 13 | undraw_personal-finance_xpqg.svg | Person managing finances with charts | 712x800 | #6c63ff | Skip — tall ratio, hard to place |
| 14 | undraw_calculator_os9t.svg | Calculator scene | 960x608 | #6c63ff | Skip — tool, no personality |
| 15 | undraw_inflation_ht0o.svg | Upward chart, anxious tone | 669x800 | #6c63ff | Skip — negative mood |
| 16 | undraw_questions_52ic (1).svg | Duplicate of #6 | 960x677 | #6c63ff | Skip — duplicate |
| 17 | undraw_pay-with-credit-card_77g6.svg | Card payment action scene | 800x334 | #6c63ff | Skip — extreme landscape ratio |
| 18 | undraw_credit-card_t6qm.svg | Standalone card illustration | 567x517 | #6c63ff | Skip — no human, feels cold |
| 19 | undraw_opinion_bp12.svg | Person giving feedback | 757x598 | #6c63ff | Skip — feedback context, not in our flow |
| 20 | undraw_navigator_2ntl.svg | Person with direction/map | 886x492 | #6c63ff | Skip — wayfinding, not financial |
| 21 | undraw_shopping-app_b80f.svg | Shopping app with cart | 960x600 | #6c63ff | Skip — ecommerce, not card selection |
| 22 | undraw_online-wishes_cb5x.svg | Person shopping online | 960x710 | #6c63ff | Skip — generic wishlist |
| 23 | undraw_web-shopping_xd5k.svg | Web shopping interface | 799x573 | #6c63ff | Skip — redundant with #21 |
| 24 | undraw_online-groceries_n03y.svg | Online grocery shopping | — | #6c63ff | Skip — too category-specific |
| 25 | undraw_connected-world_anke.svg | Global network diagram | 960x676 | #6c63ff | Skip — too abstract |
| 26 | undraw_beach-day_cnsv.svg | People at beach | 746x533 | #6c63ff | Skip — lifestyle, not financial |
| 27 | undraw_eating-together_mr7m.svg | People dining together | 960x741 | #6c63ff | Skip — lifestyle, off-brand |
| 28 | undraw_aircraft_usu4.svg | Airplane | 993x422 | blue/gray | Skip — travel imagery, no card context |
| 29 | undraw_electric-car_vlgq.svg | EV with person | 800x533 | #6c63ff | Skip — transportation |
| 30 | undraw_city-driver_kgk7.svg | Driver in city | 746x800 | #6c63ff | Skip — transportation |
| 31 | undraw_luggage_k1gn.svg | Travel luggage | 638x605 | #6c63ff | Skip — travel props, no card |
| 32 | undraw_on-the-way_zwi3.svg | Person traveling | 800x350 | #6c63ff | Skip — extreme landscape |
| 33 | undraw_at-the-airport_z3b9.svg | People at airport | 769x727 | #6c63ff | Skip — airport, not card |
| 34 | undraw_golf_wmi1.svg | Person golfing | 816x548 | #6c63ff | Skip — sports, off-brand |
| 35 | Credit card-rafiki.svg | Card interaction (Storyset) | 500x373 | #407BFF | Skip — style mismatch |
| 36 | Finance-bro.svg | Finance figure (Storyset) | 500x500 | #263238/#92E3A9 | Skip — style mismatch |
| 37 | Credit card-amico.svg | Card scene (Storyset) | 500x500 | #BA68C8 | Skip — style mismatch |
| 38 | Revenue-cuate.svg | Revenue chart (Storyset) | 500x500 | #263238/#FFC727 | Skip — style mismatch |
| 39 | Business competition-bro.svg | Competition scene (Storyset) | 500x500 | #263238/#92E3A9 | Skip — style mismatch |
| 40 | Payment Information-bro.svg | Payment form (Storyset) | 500x500 | #263238/#92E3A9 | Skip — style mismatch |
| 41 | Tax-amico.svg | Tax calculation (Storyset) | 500x500 | #BA68C8 | Skip — style mismatch |

---

## 2. Product Story Arc

| Page | Component | Emotional Beat | Current Visuals | Illustration Need |
|------|-----------|---------------|-----------------|-------------------|
| 1. Landing | LandingPage.jsx | "You're overpaying. There's a better card." | CSS card stack, floating shapes, bank marquee | **YES — hero illustration** |
| 2. Login | Login.jsx | "Join us. This is safe." | Floating card silhouettes on gradient, clean form | **NO — visuals are complete** |
| 3. Golden Question | GoldenQuestion.jsx | "What's your goal?" | Two choice cards with emojis, minimal | **NO — binary choice must stay focused** |
| 4. Welcome | WelcomeAnimation.jsx | "Let's begin. 3 minutes." | Word-by-word cinematic animation, floating bg cards | **NO — animation IS the visual** |
| 5. Layer 1 | Layer1.jsx | "Tell us who you are." | Bank logos, option tiles | **NO — form is the focus** |
| 6. Layer 2 | Layer2.jsx | "Tell us how you spend." | Sliders, emojis, brand logos | **NO — interaction is the focus** |
| 7. Layer 3 | Layer3.jsx | "Tell us how you live." | Emoji tiles, airline/hotel logos | **NO — last step, keep momentum** |
| 8. Results | Results.jsx | "Here's your perfect card." | Ranked card components, scores | **YES — celebration moment** |

---

## 3. Storyboard — Illustration Placements

### PLACEMENT 1 — Landing Page Hero

```
PAGE:             Landing
SECTION:          Hero (above the fold, right side)
ILLUSTRATION:     undraw_choose-card_es1o.svg
WHY:              Person actively choosing between cards — directly mirrors
                  "find the one built for you." Shows agency, not sales.
SIZE:             Large (440-500px width)
POSITION:         Right side of hero, text on left
COLOR TREATMENT:  #6c63ff → #1C5BC0 (all primary shapes)
                  Card highlight accent → #E09E42 (the selected card glow)
                  Gray cards → keep #d3d3d3
                  Skin tones → keep natural
                  Background → transparent
SKIP IF:          viewport < 768px (show text-only hero on mobile)
```

**Why this over other candidates:**
- `credit-card-payment_3zqz.svg` shows paying, not choosing — wrong verb
- `credit-card-payments_y0vn.svg` shows a hand, not a person — less human
- `make-it-rain_vyg9.svg` shows celebration — too early in the story
- `mobile-payments_uate.svg` shows a phone — product is web-first

The hero illustration must answer: "What will I do here?"
Answer: Choose the right card. `choose-card` shows exactly that.

---

### PLACEMENT 2 — Landing "How It Works" Step 1

```
PAGE:             Landing
SECTION:          How It Works — Step 1 "Tell Us About You"
ILLUSTRATION:     undraw_personal-information_h7kf.svg
WHY:              Person next to a profile form — matches the survey step.
SIZE:             Small (140-180px)
POSITION:         Center, above step title
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Skin tones → keep natural
SKIP IF:          Never skip — always show in step cards
```

---

### PLACEMENT 3 — Landing "How It Works" Step 2

```
PAGE:             Landing
SECTION:          How It Works — Step 2 "We Analyze"
ILLUSTRATION:     undraw_business-analytics_y8m6.svg
WHY:              Person analyzing charts — shows the engine doing its work.
SIZE:             Small (140-180px)
POSITION:         Center, above step title
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Chart accents → #E09E42
                  Skin tones → keep natural
SKIP IF:          Never skip
```

---

### PLACEMENT 4 — Landing "How It Works" Step 3

```
PAGE:             Landing
SECTION:          How It Works — Step 3 "Get Your Card"
ILLUSTRATION:     undraw_credit-card-payments_y0vn.svg
WHY:              Hand with card + confirmation — the payoff moment.
SIZE:             Small (140-180px)
POSITION:         Center, above step title
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Confirmation dialog accent → #E09E42
                  Skin tones → keep natural
SKIP IF:          Never skip
```

---

### PLACEMENT 5 — Results Page Success Header

```
PAGE:             Results
SECTION:          Above recommendations heading (after loading completes)
ILLUSTRATION:     undraw_make-it-rain_vyg9.svg
WHY:              Celebration — "we found your cards!" Emotional payoff
                  after 3 minutes of survey work. The user earned this moment.
SIZE:             Medium (260-320px)
POSITION:         Center, between heading and first card
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Money/confetti accents → #E09E42
                  Skin tones → keep natural
SKIP IF:          API error state (show error illustration instead)
                  Zero results (show questions illustration instead)
```

---

### PLACEMENT 6 — Results Page Empty State

```
PAGE:             Results
SECTION:          Empty state (no matching cards or incomplete survey)
ILLUSTRATION:     undraw_questions_52ic.svg
WHY:              Thinking person with question marks — "we need more info"
                  or "try adjusting your preferences." Non-judgmental.
SIZE:             Medium (240-280px)
POSITION:         Center
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Question marks → #E09E42
                  Skin tones → keep natural
SKIP IF:          Never — this IS the empty state visual
```

---

### PLACEMENT 7 — API Error State

```
PAGE:             Results (error branch)
SECTION:          Error state (API failure)
ILLUSTRATION:     undraw_server-error_syuz.svg
WHY:              Server error — honest about what happened.
                  Better than a generic "something went wrong" with no visual.
SIZE:             Medium (220-260px)
POSITION:         Center
COLOR TREATMENT:  #6c63ff → #1C5BC0
SKIP IF:          Never — this IS the error visual
```

---

### PLACEMENT 8 — 404 Page

```
PAGE:             404 / Not Found
SECTION:          Full page
ILLUSTRATION:     undraw_page-not-found_6wni.svg
WHY:              Standard 404 with personality. Shows the product has polish
                  even in edge cases. Users who hit this should smile, not leave.
SIZE:             Large (360-420px)
POSITION:         Center, above "Go Home" button
COLOR TREATMENT:  #6c63ff → #1C5BC0
                  Pink accent #ff6884 → #E09E42
SKIP IF:          Never — this IS the 404 page
```

---

## 4. Landing Page Hero Plan

### Current State

The landing hero uses a CSS-animated 3D card stack with floating gradient
shapes. It's technically impressive but abstract — it doesn't show a
*person* making a *choice*. The Finology Select reference leads with bold
human messaging and relatable visuals.

### Recommended Hero Layout

```
┌──────────────────────────────────────────────────────────┐
│  NAVBAR  [Logo Finoptima]            [How It Works] [Get Started]  │
├──────────────────────────────────────────────────────────┤
│                                                          │
│   Stop getting sold.              ┌─────────────────┐   │
│   Find your perfect card.        │                   │   │
│                                   │  [choose-card     │   │
│   Answer a few questions about    │   illustration    │   │
│   how you spend. We'll find the   │   440px wide      │   │
│   card actually built for         │   recolored to    │   │
│   your life.                      │   brand palette]  │   │
│                                   │                   │   │
│   [Find My Card]  [How It Works]  └─────────────────┘   │
│                                                          │
│   100% Free · 3 Minutes · 46+ Cards Analyzed            │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

### Headline Treatment

```
Stop getting sold.              ← 48-56px, Plus Jakarta Sans 800, #1A1A2E
Find your perfect card.         ← Same weight, "perfect card" in #1C5BC0
```

The first line is the HOOK — confrontational, relatable, emotional.
The second line is the PROMISE — positive, specific, personal.

This follows the Finology Select pattern:
  "Don't be a Sales Target" (hook) → "Escape mediocrity with Select" (promise)

### Supporting Copy

"Answer a few questions about how you spend.
We'll find the card actually built for your life."

- 18px Inter 400, #6A6B6B
- Two lines maximum
- "actually" does the work — implies other tools don't do this

### Trust Badges (below CTAs)

"100% Free  ·  3 Minutes  ·  46+ Cards Analyzed"
- 14px Inter 500, #ABABAB
- No emojis — let the words be clean

### Background Treatment

- Base: #FAFCFB (brand white)
- NO gradient behind illustration — keep it editorial and clean
- Subtle: 2-3 abstract dots/circles at 4-6% opacity in #1C5BC0
  floating in background for depth (similar to current floating shapes
  but much more restrained)
- The illustration provides all the visual weight the hero needs

### Mobile Behavior (< 768px)

- Illustration hidden (same as current left-panel-hidden pattern)
- Headline stacks vertically, drops to 36px
- CTA becomes full-width
- Trust badges wrap to two lines

---

## 5. Illustration Style Guide

### Selected Illustrations (8 files)

| # | File | Used On | Role |
|---|------|---------|------|
| 1 | undraw_choose-card_es1o.svg | Landing hero | Primary hero |
| 2 | undraw_personal-information_h7kf.svg | Landing Step 1 | Step icon |
| 3 | undraw_business-analytics_y8m6.svg | Landing Step 2 | Step icon |
| 4 | undraw_credit-card-payments_y0vn.svg | Landing Step 3 | Step icon |
| 5 | undraw_make-it-rain_vyg9.svg | Results success | Celebration |
| 6 | undraw_questions_52ic.svg | Results empty | Empty state |
| 7 | undraw_server-error_syuz.svg | Results error | Error state |
| 8 | undraw_page-not-found_6wni.svg | 404 page | Not found |

### Reserve (not used now, available if needed)

| # | File | Potential Use |
|---|------|---------------|
| 9 | undraw_mobile-payments_uate.svg | If mobile app section added |
| 10 | undraw_credit-card-payment_3zqz.svg | Alternative for Step 3 |

### Skipped (31 files) — Reasons

**Style mismatch (7):** All Storyset files (rafiki, bro, amico, cuate).
Different visual language, inconsistent palettes, heavy SVG files.
Mixing styles signals unpolished design.

**Off-brand lifestyle (9):** beach-day, eating-together, aircraft,
electric-car, city-driver, luggage, on-the-way, at-the-airport, golf.
None relate to credit card selection. Would dilute product focus.

**Redundant or weaker (9):** pay-online, payments, personal-finance,
pay-with-credit-card, online-wishes, web-shopping, online-groceries,
shopping-app, credit-card (standalone).
Either covered by a better selection or wrong aspect ratio.

**Wrong mood (3):** inflation (anxiety), calculator (no personality),
connected-world (too abstract).

**Duplicate (1):** questions_52ic (1).svg.

**Not needed (2):** navigator, opinion. Outside our page flow.

---

### Color Treatment — Applied to ALL Selected SVGs

```
FIND                    REPLACE WITH        ELEMENT
─────────────────────────────────────────────────────
#6c63ff                 #1C5BC0             All primary shapes, buttons, clothing
#6c63ff at 20% opacity  #1C5BC0 at 12%      Background shapes, shadows
Secondary pink/coral    #E09E42             Accent highlights (card glow, confetti,
                                            chart bars, question marks)
#ff6884                 #E09E42             Page-not-found accent
#2f2e41 / #3f3d56       #1A1A2E             Dark elements (hair, shoes, devices)
Skin tones              KEEP AS-IS          All skin-colored fills
#e6e6e6 / #d3d3d3       KEEP AS-IS          Grays, borders, neutral shapes
#f2f2f2 / #f5f5f5       KEEP AS-IS          Light fills
```

Do this via CSS filter OR direct SVG find-replace before deployment.
Direct SVG edit is preferred — CSS filters affect skin tones.

---

### Size Scale

| Role | Width | Use Case |
|------|-------|----------|
| Large | 400-500px | Landing hero, 404 page |
| Medium | 240-320px | Results celebration, empty/error states |
| Small | 140-180px | How It Works step icons |

All illustrations are SVG — scale cleanly at any size.
Never stretch. Always maintain aspect ratio via `object-fit: contain`.

---

### Spacing Rules

- Hero illustration: 40px padding from text column, 60px from page edge
- Step icons: 24px below section top, 16px above step title
- State illustrations (error/empty): 32px margin-bottom from text below
- All illustrations: never touch the viewport edge on any side
- Minimum breathing room: 24px on all sides

---

### What NOT To Do

1. **Do not mix unDraw and Storyset.** One visual language per product.
2. **Do not use illustrations on survey pages.** They distract from the task.
   The emojis, bank logos, and brand tiles already serve as visual anchors.
3. **Do not add illustrations to fill empty space.** If a page feels empty,
   fix the layout — don't wallpaper over it.
4. **Do not resize illustrations below 120px.** They lose legibility.
   Use an icon or emoji instead.
5. **Do not use illustrations as backgrounds.** They are foreground elements.
   Low-opacity illustration backgrounds look amateurish.
6. **Do not animate the illustrations.** The product already has
   purposeful animations (word reveals, card floats, slider interactions).
   Animating illustrations would compete.
7. **Do not add drop shadows to illustrations.** They are flat-style.
   Shadows break the visual contract of the illustration style.
8. **Do not crop illustrations.** They are composed with intentional
   negative space. Cropping creates visual tension.
9. **Do not use more than one illustration per viewport.** One message
   per scroll position. The How It Works section is an exception because
   the three illustrations form a sequential story within one section.

---

## 6. Design Philosophy Reference

### From Finology Select (reference PDFs)

What they do well:
- Bold, confrontational headlines ("Don't be a Sales Target")
- Clean category grids with custom icons (privilege cards page)
- Income bracket presented as friendly circles, not intimidating forms
- Fun emoji use in taglines without undermining credibility
- Dark navy footer contrasting with white content
- Generous whitespace — content breathes

What Finoptima should evolve beyond:
- Select uses generic stock icons — our unDraw illustrations add personality
- Select's category pages are flat grids — our survey flow is interactive
- Select doesn't show a "journey" — our 8-page arc tells a story
- Select is an aggregator — Finoptima is a recommendation engine with opinion

### Design Principles for Phase 2 Rebuild

1. **Illustrations serve the story.** Each placement maps to an emotional beat.
   Landing = "choose." Results = "celebrate." Error = "we're honest."

2. **Survey pages are tools, not magazines.** No illustrations. No decoration.
   The user is working. Respect their focus.

3. **The hero sells the promise.** A person choosing a card, not a card
   selling itself. The user is the protagonist.

4. **Consistency over variety.** 8 illustrations from one style family
   beats 20 from mixed sources.

5. **White space is a feature.** The Finology Select reference proves:
   a page with room to breathe feels premium. A page crammed with
   visuals feels desperate.

---

## Summary

```
Total illustrations available:   41
Selected for use:                 8
Held in reserve:                  2
Skipped:                         31

Pages that get illustrations:
  - Landing Page (hero + 3 step icons)
  - Results Page (success celebration + empty state + error state)
  - 404 Page

Pages that stay clean:
  - Login
  - Golden Question
  - Welcome Animation
  - Layer 1 Survey
  - Layer 2 Survey
  - Layer 3 Survey
```

---

*Storyboard created 2026-03-27.*
*Awaiting approval before Phase 2 build begins.*
